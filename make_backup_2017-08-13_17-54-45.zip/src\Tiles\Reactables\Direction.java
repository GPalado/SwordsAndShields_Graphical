package Tiles.Reactables;

public enum Direction {
        TO_RIGHT,
        TO_LEFT,
        ABOVE,
        BELOW
}
